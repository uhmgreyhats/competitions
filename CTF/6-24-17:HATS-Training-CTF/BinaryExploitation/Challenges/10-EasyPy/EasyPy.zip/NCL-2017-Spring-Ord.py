import sys

def verify(guess):
    vals = [
        72,
        65,
        84,
        83,
        45,
        69,
        65,
        83,
        89,
        45,
        50,
        48,
        49,
        55,
    ]
    for i, c in enumerate(guess):
        if ord(c) != vals[i]:

           return False
    return True


if len(sys.argv) != 1:
    print ("Usage: python check.pyc")
    exit(1)

guess = input("Enter your guess for the flag: ")


if verify(guess):
    print ("That's the correct flag!")
else:
    print ("Wrong flag.")
